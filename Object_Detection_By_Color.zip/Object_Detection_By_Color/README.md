# If you use MacOS, you need to install this following python libraries
pip install opencv-contrib-python
pip install opencv-python-headless

